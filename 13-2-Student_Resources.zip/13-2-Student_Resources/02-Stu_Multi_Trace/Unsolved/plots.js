console.log(data);

// Trace1 for the Greek Data


// Trace 2 for the Roman Data


// Combining both traces


// Apply the group barmode to the layout


// Render the plot to the div tag with id "plot"
