// Create an array of each country's numbers
var us = Object.values(data.us);
var uk = Object.values(data.uk);
var canada = Object.values(data.canada);

// Create an array of music provider labels


// Display the default plot


// On change to the DOM, call getData()

// Function called by DOM changes

  // Assign the value of the dropdown menu option to a variable

  // Initialize an empty array for the country's data


// Update the restyled plot's values
